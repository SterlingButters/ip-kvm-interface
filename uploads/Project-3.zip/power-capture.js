resetButton = document.getElementById('resetTarget');
gpioTargets = document.getElementById('gpioTargets');

var socketTx = io();

resetButton.onclick = function resetTarget() {
  socketTx.emit('powerChannel', gpioTargets.value);
}
